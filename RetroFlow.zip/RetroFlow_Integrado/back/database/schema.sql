-- Esquema inicial compatible con los modelos Sprint y RetroItem.
CREATE TABLE IF NOT EXISTS sprints (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 nombre VARCHAR(100) NOT NULL,
 fecha_inicio DATE NOT NULL,
 fecha_fin DATE NOT NULL,
 created_at TIMESTAMP NULL DEFAULT NULL,
 updated_at TIMESTAMP NULL DEFAULT NULL,
 PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS retro_items (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 sprint_id BIGINT UNSIGNED NOT NULL,
 categoria VARCHAR(20) NOT NULL,
 descripcion TEXT NOT NULL,
 cumplida TINYINT(1) NULL DEFAULT NULL,
 fecha_revision DATE NULL DEFAULT NULL,
 created_at TIMESTAMP NULL DEFAULT NULL,
 updated_at TIMESTAMP NULL DEFAULT NULL,
 PRIMARY KEY (id),
 KEY idx_retro_items_sprint_id (sprint_id),
 CONSTRAINT fk_retro_items_sprint FOREIGN KEY (sprint_id) REFERENCES sprints(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
