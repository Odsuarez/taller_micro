<?php
declare(strict_types=1);
// Sirve la interfaz y sus recursos desde el mismo origen; el resto pasa a Slim.
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
if ($path === '/') {
    header('Content-Type: text/html; charset=utf-8');
    readfile(__DIR__ . '/index.html');
    return true;
}
$file = __DIR__ . $path;
if (is_file($file)) {
    return false; // El servidor PHP entrega el recurso estático.
}
require __DIR__ . '/index.php';
