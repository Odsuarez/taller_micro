<?php
declare(strict_types=1);
use Illuminate\Database\Capsule\Manager as Capsule;
$env = static function (string $key, mixed $default = null): mixed {
    if (isset($_ENV[$key]) && $_ENV[$key] !== '') return $_ENV[$key];
    $value = getenv($key);
    return ($value !== false && $value !== '') ? $value : $default;
};
$capsule = new Capsule();
$driver = (string) $env('DB_DRIVER', 'mysql');
if ($driver === 'sqlite') {
    $connection = ['driver'=>'sqlite','database'=>$env('DB_DATABASE', __DIR__.'/../../database/retroflow.sqlite'),'prefix'=>'','foreign_key_constraints'=>true];
} else {
    $connection = ['driver'=>'mysql','host'=>$env('DB_HOST','127.0.0.1'),'port'=>$env('DB_PORT','3306'),'database'=>$env('DB_DATABASE','registro_retro_db'),'username'=>$env('DB_USERNAME','root'),'password'=>$env('DB_PASSWORD',''),'charset'=>'utf8mb4','collation'=>'utf8mb4_unicode_ci','prefix'=>'','strict'=>true];
}
$capsule->addConnection($connection);
$capsule->setAsGlobal();
$capsule->bootEloquent();
return $capsule;
