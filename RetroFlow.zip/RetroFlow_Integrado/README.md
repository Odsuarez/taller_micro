# RetroFlow Integrado

Proyecto único que integra el frontend RetroFlow (HTML/CSS/JavaScript) con la API PHP Slim 4 / Eloquent del backend entregado.

## Estructura
- `back/retrospectivas_ms/public/`: frontend y punto de entrada de la API.
- `back/retrospectivas_ms/app/`: controladores, modelos, servicios, middlewares y rutas.
- `back/retrospectivas_ms/vendor/`: dependencias Composer incluidas.
- `back/database/schema.sql`: esquema SQL para las tablas usadas por los modelos.
- `back/endpoints.http`: ejemplos de las rutas originales.

## Requisitos
- PHP 8.2 o superior.
- Extensiones PHP `pdo`, `pdo_mysql`, `mbstring` y `json`.
- MySQL/MariaDB.
- Composer solo para reinstalar/actualizar dependencias; `vendor` ya viene incluido.

## Instalación y ejecución
1. Crea una base de datos, por ejemplo `registro_retro_db`.
2. Ejecuta `back/database/schema.sql` sobre esa base de datos.
3. Configura las credenciales en `back/retrospectivas_ms/app/global/database_config.php` o exporta `DB_HOST`, `DB_PORT`, `DB_DATABASE`, `DB_USERNAME` y `DB_PASSWORD`.
4. Entra en `back/retrospectivas_ms` desde una terminal.
5. Ejecuta `composer start`.
6. Abre `http://127.0.0.1:8000`.

El frontend y la API se sirven desde el mismo origen. La conexión viene configurada automáticamente; no necesitas Live Server ni configurar CORS para el uso local.

## Funciones conectadas
- Panel de resumen, sprint actual y próximo.
- Listado, búsqueda y filtro de sprints.
- Crear sprint y seleccionar acciones pendientes del último sprint finalizado.
- Consultar detalle y retrospectiva.
- Agregar y eliminar acciones, logros, impedimentos y comentarios.
- Finalizar retrospectiva y guardar realizadas, adicionales, logros, impedimentos, comentarios y acuerdos.
- Historial, estado de API y configuración manual de URL.

## Notas
- El backend original no incluía migraciones ni creación de tablas. Se agregó `back/database/schema.sql` a partir de los campos usados por `Sprint` y `RetroItem`; ejecútalo antes del primer uso.
- No se agregaron datos ficticios ni autenticación: la API original no implementa login.
- Se conservaron las reglas de negocio originales, incluida la confirmación de cierre anticipado y el bloqueo de navegación por retrospectivas pendientes.
