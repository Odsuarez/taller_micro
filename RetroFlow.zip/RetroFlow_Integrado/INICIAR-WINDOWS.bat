@echo off
cd /d "%~dp0back\retrospectivas_ms"
echo Iniciando RetroFlow en http://127.0.0.1:8000
composer start
pause
